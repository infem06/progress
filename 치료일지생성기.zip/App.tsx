
import React, { useState, useEffect } from 'react';
import { 
  Users, PlusCircle, FileText, Search, Activity, Home,
  UserPlus, ArrowLeft, Loader2, LogOut, Sparkles,
  ChevronDown, ChevronUp, CheckCircle2, AlertCircle, ChevronRight, Download, Save, FileSpreadsheet, Calendar
} from 'lucide-react';
import { GoogleGenAI, Type } from "@google/genai";

// --- Types & Enums ---
enum Diagnosis {
  ASD = '자폐스펙트럼',
  ADHD = '주의력결핍 과잉행동장애',
  ID = '지적장애',
  CP = '뇌병변',
  DD = '발달지연',
  PHYSICAL = '지체장애',
  LANGUAGE = '언어장애',
  VISUAL = '시각장애',
  OTHER = '기타'
}

enum DisabilitySeverity {
  SEVERE = '심한 장애',
  NOT_SEVERE = '심하지 않은 장애'
}

enum Gender {
  MALE = '남',
  FEMALE = '여'
}

interface Patient {
  id: string;
  name: string;
  gender: Gender;
  birthDate: string;
  diagnosis: Diagnosis;
  disabilitySeverity: DisabilitySeverity;
  goals: string[];
  initialAssessment: string; 
  initialAssessmentDate: string;
  interimAssessment: string; 
  interimAssessmentDate: string;
  finalAssessment: string;   
  finalAssessmentDate: string;
  therapyStartDate: string;
}

interface TherapyLog {
  id: string;
  patientId: string;
  date: string;
  activityName: string;
  generatedLog: string;
  createdAt: number;
}

export default function App() {
  const [user] = useState({ name: '김주영' });
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => localStorage.getItem('ot_auth_session') === 'true');
  
  // 데이터 불러오기 (localStorage)
  const [patients, setPatients] = useState<Patient[]>(() => {
    try {
      const saved = localStorage.getItem('ot_patients_data');
      return saved ? JSON.parse(saved) : [];
    } catch (e) { return []; }
  });
  const [logs, setLogs] = useState<TherapyLog[]>(() => {
    try {
      const saved = localStorage.getItem('ot_logs_data');
      return saved ? JSON.parse(saved) : [];
    } catch (e) { return []; }
  });

  const [view, setView] = useState<'dashboard' | 'patients' | 'add_patient' | 'patient_detail' | 'generate_log'>('dashboard');
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [expandedAssessments, setExpandedAssessments] = useState<{ [key: string]: boolean }>({});
  
  // 기간 선택 저장용 상태
  const [exportRange, setExportRange] = useState({
    start: new Date().toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0]
  });

  const selectedPatient = patients.find(p => p.id === selectedPatientId);

  // 데이터 영구 보관 (상태 변경 시마다 localStorage 업데이트)
  useEffect(() => {
    localStorage.setItem('ot_patients_data', JSON.stringify(patients));
  }, [patients]);

  useEffect(() => {
    localStorage.setItem('ot_logs_data', JSON.stringify(logs));
  }, [logs]);

  const toggleAssessment = (key: string) => {
    setExpandedAssessments(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleDeleteLog = (id: string) => {
    if (confirm("이 기록을 삭제하시겠습니까? 데이터 보관소에서도 영구히 삭제됩니다.")) {
      setLogs(prev => prev.filter(l => l.id !== id));
    }
  };

  // --- 저장 및 다운로드 기능 ---
  const downloadFile = (content: string, fileName: string, contentType: string) => {
    const a = document.createElement("a");
    const file = new Blob([content], { type: contentType });
    a.href = URL.createObjectURL(file);
    a.download = fileName;
    a.click();
  };

  const exportFilteredLogs = (format: 'txt' | 'csv') => {
    if (!selectedPatient) return;

    const filtered = logs.filter(l => 
      l.patientId === selectedPatient.id && 
      l.date >= exportRange.start && 
      l.date <= exportRange.end
    ).sort((a, b) => a.date.localeCompare(b.date));

    if (filtered.length === 0) {
      alert("선택한 기간에 해당하는 일지가 없습니다.");
      return;
    }

    if (format === 'txt') {
      let content = `[${selectedPatient.name}] 치료 기록지 (${exportRange.start} ~ ${exportRange.end})\n`;
      content += `진단명: ${selectedPatient.diagnosis}\n`;
      content += `==========================================\n\n`;
      filtered.forEach(log => {
        content += `일자: ${log.date}\n`;
        content += `${log.generatedLog}\n`;
        content += `------------------------------------------\n\n`;
      });
      downloadFile(content, `${selectedPatient.name}_기록_${exportRange.start}_${exportRange.end}.txt`, 'text/plain;charset=utf-8');
    } else {
      let csv = "\uFEFF"; // BOM
      csv += "날짜,활동명,치료내용\n";
      filtered.forEach(log => {
        const escapedLog = `"${log.generatedLog.replace(/"/g, '""')}"`;
        csv += `${log.date},${log.activityName},${escapedLog}\n`;
      });
      downloadFile(csv, `${selectedPatient.name}_일지_${exportRange.start}_${exportRange.end}.csv`, 'text/csv;charset=utf-8');
    }
  };

  // --- AI 일지 생성 로직 (요청하신 양식 엄격 적용) ---
  const handleGenerateBatchLogs = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedPatient) return;
    
    setIsGenerating(true);
    const formData = new FormData(e.currentTarget);
    const activityInput = formData.get('activity') as string;
    const startDate = formData.get('date') as string;

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const model = "gemini-3-flash-preview";
      
      const prompt = `당신은 16년차 베테랑 작업치료사입니다. 
      이용자 [${selectedPatient.name}]에 대한 5일치 치료 일지를 작성하세요.
      
      [필수 양식 준수 - 매우 중요]
      *제목: (활동명)
      - (수행 기록 1)
      - (수행 기록 2)
      - (수행 기록 3)
      - (수행 기록 4)
      - (수행 기록 5)

      *상담내용
      치료내용 상담

      [작성 가이드]
      1. '*제목' 바로 다음 줄부터 하이픈(-)으로 시작하는 수행 기록을 시작하세요 (사이에 빈 줄 없음).
      2. 항목 간에는 반드시 줄바꿈(Enter)을 넣어 행을 구분하세요.
      3. 숫자(1., 2.)는 절대 사용하지 말고 오직 하이픈(-)만 사용하세요.
      4. 5번째 하이픈 항목과 '*상담내용' 사이에는 반드시 한 줄의 빈 줄(\\n\\n)을 넣으세요.
      5. '*상담내용' 바로 아래 줄에는 반드시 '치료내용 상담'이라고만 적으세요. 다른 말은 덧붙이지 마십시오.
      6. 치료 목표(${selectedPatient.goals.join(", ")})와 키워드[${activityInput}]를 개조식(~함, ~됨)으로 반영하세요.

      반드시 JSON 'logs' 배열로 date, activityName, content를 포함해 응답하세요.`;

      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: { 
          temperature: 0.8,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              logs: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    date: { type: Type.STRING },
                    activityName: { type: Type.STRING },
                    content: { type: Type.STRING }
                  },
                  required: ["date", "activityName", "content"]
                }
              }
            },
            required: ["logs"]
          }
        }
      });

      const generatedData = JSON.parse(response.text || "{}").logs;
      const newLogs: TherapyLog[] = generatedData.map((log: any, idx: number) => ({
        id: (Date.now() + idx).toString(),
        patientId: selectedPatient.id,
        date: log.date,
        activityName: log.activityName,
        generatedLog: log.content,
        createdAt: Date.now() + idx
      }));

      setLogs(prev => [...newLogs, ...prev]);
      setView('patient_detail');
    } catch (error) {
      alert("일지 생성 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsAuthenticated(true);
    localStorage.setItem('ot_auth_session', 'true');
  };

  const [newPatientForm, setNewPatientForm] = useState({ 
    name: '', gender: Gender.MALE, birthDate: '', diagnosis: Diagnosis.ASD, 
    disabilitySeverity: DisabilitySeverity.SEVERE, goals: '', initialAssessment: '', 
    initialAssessmentDate: new Date().toISOString().split('T')[0], 
    interimAssessment: '', interimAssessmentDate: '', 
    finalAssessment: '', finalAssessmentDate: '', 
    therapyStartDate: new Date().toISOString().split('T')[0]
  });

  const handleAddPatient = (e: React.FormEvent) => {
    e.preventDefault();
    const newPatient: Patient = { 
      id: Date.now().toString(), 
      ...newPatientForm, 
      goals: newPatientForm.goals.split(',').map(g => g.trim()).filter(g => g !== ''), 
    };
    setPatients(prev => [...prev, newPatient]);
    setView('patients');
  };

  if (!isAuthenticated) return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6 font-sans">
      <div className="max-w-md w-full bg-white rounded-[3rem] shadow-2xl p-12 animate-in fade-in zoom-in duration-500">
        <div className="flex flex-col items-center mb-10">
          <div className="w-16 h-16 bg-emerald-500 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-emerald-200">
            <Activity className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-black text-slate-800">OT Master</h1>
          <p className="text-slate-400 font-bold mt-2">안전한 데이터 보관 및 AI 생성기</p>
        </div>
        <form onSubmit={handleLogin} className="space-y-5">
          <input placeholder="Username" required className="w-full p-5 bg-slate-50 border-none rounded-2xl outline-none font-bold shadow-inner focus:ring-2 focus:ring-emerald-500 transition-all" />
          <input type="password" placeholder="Password" required className="w-full p-5 bg-slate-50 border-none rounded-2xl outline-none font-bold shadow-inner focus:ring-2 focus:ring-emerald-500 transition-all" />
          <button type="submit" className="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black text-lg shadow-xl hover:bg-emerald-700 transition-all active:scale-95">LOGIN</button>
        </form>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row text-slate-900 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-full md:w-80 bg-slate-900 text-white p-8 flex flex-col md:h-screen shadow-2xl z-20">
        <div className="flex items-center gap-4 mb-16">
          <div className="p-2 bg-emerald-500 rounded-lg">
            <Activity className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-black tracking-tight">OT MASTER</h1>
        </div>
        
        <nav className="flex-1 space-y-3">
          <NavItem active={view === 'dashboard'} onClick={() => setView('dashboard')} icon={<Home/>} label="대시보드" />
          <NavItem active={view === 'patients' || view === 'patient_detail' || view === 'generate_log'} onClick={() => setView('patients')} icon={<Users/>} label="이용자 관리" />
          <NavItem active={view === 'add_patient'} onClick={() => setView('add_patient')} icon={<UserPlus/>} label="신규 이용자" />
        </nav>

        <div className="mt-auto pt-8 border-t border-slate-800">
          <div className="flex items-center gap-4 mb-6 px-4">
             <div className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center font-black text-white">{user.name[0]}</div>
             <div>
               <p className="text-sm font-black">{user.name} 선생님</p>
               <p className="text-[10px] text-emerald-500 font-bold">실시간 데이터 보관 중</p>
             </div>
          </div>
          <button onClick={() => { setIsAuthenticated(false); localStorage.removeItem('ot_auth_session'); }} className="w-full flex items-center justify-center gap-2 py-4 rounded-xl text-slate-500 hover:text-white hover:bg-slate-800 transition-all font-black uppercase text-[10px] tracking-widest">
            <LogOut className="w-4 h-4" /> 로그아웃
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto p-6 md:p-12 relative z-10">
        {view === 'dashboard' && (
          <div className="max-w-6xl mx-auto space-y-12 animate-in fade-in duration-700">
            <header>
              <h2 className="text-5xl font-black text-slate-800 tracking-tighter">안녕하세요, {user.name} 선생님!</h2>
              <p className="text-slate-400 font-bold text-lg mt-1">저장된 모든 기록은 브라우저를 닫아도 안전하게 유지됩니다.</p>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <StatCard icon={<Users className="text-blue-500"/>} label="관리 이용자" value={`${patients.length}명`} />
              <StatCard icon={<FileText className="text-emerald-500"/>} label="누적 치료 일지" value={`${logs.length}건`} />
              <StatCard icon={<CheckCircle2 className="text-purple-500"/>} label="데이터 상태" value="안전 보관됨" />
            </div>

            <div className="bg-white p-12 rounded-[4rem] border border-slate-100 shadow-xl flex flex-col md:flex-row items-center justify-between gap-12 group transition-all hover:shadow-2xl">
              <div className="flex items-center gap-8">
                <div className="w-24 h-24 bg-emerald-50 rounded-[2.5rem] flex items-center justify-center text-emerald-500 transition-transform group-hover:scale-110">
                  <Sparkles className="w-12 h-12" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-3xl font-black text-slate-800 tracking-tight">AI 치료 일지 생성이 준비되었습니다</h3>
                  <p className="text-slate-500 font-medium text-lg">하이픈(-) 기호와 자동 상담 문구를 적용한 전문적인 양식을 제공합니다.</p>
                </div>
              </div>
              <button onClick={() => setView('patients')} className="w-full md:w-auto px-12 py-6 bg-slate-900 text-white rounded-[2rem] font-black text-xl shadow-2xl hover:bg-slate-800 transition-all">이용자 차트 열기</button>
            </div>
          </div>
        )}

        {view === 'patients' && (
          <div className="max-w-6xl mx-auto space-y-10 animate-in fade-in duration-700">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
              <h2 className="text-4xl font-black text-slate-800 tracking-tighter">이용자 관리</h2>
              <div className="relative w-full md:w-96 group">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 w-6 h-6 group-focus-within:text-emerald-500 transition-colors" />
                <input type="text" placeholder="이름으로 검색..." className="w-full pl-16 pr-8 py-6 bg-white border-2 border-transparent rounded-[2.5rem] shadow-xl focus:border-emerald-500/20 outline-none font-black text-lg transition-all" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
              {patients.filter(p => p.name.includes(searchTerm)).map(patient => (
                <div key={patient.id} className="bg-white p-10 rounded-[3.5rem] shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all cursor-pointer group relative overflow-hidden" onClick={() => { setSelectedPatientId(patient.id); setView('patient_detail'); }}>
                  <div className="absolute top-0 right-0 w-32 h-32 bg-slate-50 rounded-bl-[4rem] -mr-16 -mt-16 group-hover:bg-emerald-50 transition-colors"></div>
                  <h4 className="text-3xl font-black text-slate-800 relative z-10 tracking-tighter">{patient.name} <span className="text-sm text-slate-300 font-bold ml-2">{patient.gender}성</span></h4>
                  <p className="text-[11px] text-slate-400 font-black uppercase tracking-[0.2em] mt-2 mb-12 relative z-10">{patient.diagnosis}</p>
                  
                  <div className="flex justify-between items-center pt-8 border-t border-slate-50">
                    <div>
                      <span className="text-[10px] font-black text-slate-300 uppercase block tracking-widest mb-1">치료 시작일</span>
                      <p className="text-sm font-black text-slate-700">{patient.therapyStartDate}</p>
                    </div>
                    <div className="p-4 bg-slate-50 rounded-2xl group-hover:bg-emerald-500 group-hover:text-white transition-all">
                      <ChevronRight className="w-6 h-6" />
                    </div>
                  </div>
                </div>
              ))}
              <button onClick={() => setView('add_patient')} className="border-4 border-dashed border-slate-200 rounded-[3.5rem] p-12 flex flex-col items-center justify-center text-slate-300 hover:text-emerald-500 hover:border-emerald-500 hover:bg-emerald-50/20 transition-all min-h-[300px] group">
                <PlusCircle className="w-20 h-20 mb-6 group-hover:scale-110 transition-transform" />
                <p className="font-black text-lg uppercase tracking-widest">신규 이용자 등록</p>
              </button>
            </div>
          </div>
        )}

        {view === 'patient_detail' && selectedPatient && (
          <div className="max-w-6xl mx-auto space-y-12 animate-in slide-in-from-right-8 duration-700 pb-20">
            <button onClick={() => setView('patients')} className="flex items-center gap-3 text-slate-400 hover:text-emerald-600 font-black text-xs uppercase tracking-[0.2em] transition-colors"><ArrowLeft className="w-5 h-5"/> 목록으로 돌아가기</button>
            
            <div className="bg-white rounded-[5rem] shadow-2xl p-12 md:p-20 relative overflow-hidden border border-slate-100">
              <div className="absolute top-0 left-0 w-4 h-full bg-emerald-500"></div>
              
              <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-12 mb-20">
                <div className="space-y-6">
                  <div className="flex items-center gap-8">
                    <h2 className="text-6xl md:text-8xl font-black text-slate-800 tracking-tighter">{selectedPatient.name}</h2>
                    <span className="px-6 py-2.5 bg-slate-100 rounded-2xl text-sm font-black text-slate-500 uppercase tracking-widest">{selectedPatient.gender}성</span>
                  </div>
                  <div className="flex flex-wrap gap-4">
                    <span className="px-6 py-2.5 bg-emerald-50 text-emerald-600 rounded-2xl text-[12px] font-black uppercase tracking-[0.15em]">{selectedPatient.diagnosis}</span>
                    <span className="px-6 py-2.5 bg-blue-50 text-blue-600 rounded-2xl text-[12px] font-black uppercase tracking-[0.15em]">{selectedPatient.disabilitySeverity}</span>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-4 w-full xl:w-auto">
                   <button onClick={() => setView('generate_log')} className="w-full xl:w-auto px-12 py-7 bg-emerald-600 text-white rounded-[2rem] font-black text-xl flex items-center justify-center gap-4 shadow-2xl shadow-emerald-200 hover:bg-emerald-700 transition-all active:scale-95">
                      <Sparkles className="w-7 h-7"/> AI 5일치 일지 생성
                   </button>
                </div>
              </div>

              {/* 기간 선택 저장 도구 */}
              <div className="bg-slate-900 rounded-[3rem] p-10 mt-12 text-white shadow-2xl flex flex-col lg:flex-row items-center gap-10">
                <div className="flex items-center gap-6">
                  <div className="p-4 bg-emerald-500 rounded-2xl">
                    <Calendar className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h4 className="text-xl font-black tracking-tight">기간 선택 저장</h4>
                    <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">원하는 날짜 범위만 추출</p>
                  </div>
                </div>
                <div className="flex-1 flex flex-wrap gap-6 items-center">
                  <div className="flex flex-col gap-2">
                    <span className="text-[10px] font-black text-slate-500 uppercase ml-2">시작 날짜</span>
                    <input type="date" value={exportRange.start} onChange={(e) => setExportRange({...exportRange, start: e.target.value})} className="bg-slate-800 border-none rounded-xl p-4 font-black text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-all" />
                  </div>
                  <div className="flex flex-col gap-2">
                    <span className="text-[10px] font-black text-slate-500 uppercase ml-2">종료 날짜</span>
                    <input type="date" value={exportRange.end} onChange={(e) => setExportRange({...exportRange, end: e.target.value})} className="bg-slate-800 border-none rounded-xl p-4 font-black text-sm outline-none focus:ring-2 focus:ring-emerald-500 transition-all" />
                  </div>
                  <div className="flex gap-4 ml-auto pt-4 lg:pt-0">
                    <button onClick={() => exportFilteredLogs('txt')} className="px-8 py-4 bg-white text-slate-900 rounded-xl font-black text-sm hover:bg-emerald-500 hover:text-white transition-all">TXT 내보내기</button>
                    <button onClick={() => exportFilteredLogs('csv')} className="px-8 py-4 bg-emerald-600 text-white rounded-xl font-black text-sm hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-900/20">Excel 저장</button>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-10">
              <div className="flex items-center justify-between px-6">
                 <h3 className="text-4xl font-black text-slate-800 tracking-tight">치료 기록 내역 <span className="text-emerald-500 ml-3">({logs.filter(l => l.patientId === selectedPatient.id).length})</span></h3>
              </div>

              {logs.filter(l => l.patientId === selectedPatient.id).length === 0 ? (
                <div className="p-32 bg-white rounded-[4rem] border-4 border-dashed border-slate-100 flex flex-col items-center justify-center text-slate-300">
                  <FileText className="w-24 h-24 mb-6 opacity-10" />
                  <p className="font-black text-2xl text-slate-400 uppercase tracking-widest">저장된 기록이 없습니다</p>
                  <p className="text-slate-300 font-bold mt-2">상단의 AI 일지 생성 버튼을 눌러보세요.</p>
                </div>
              ) : (
                <div className="space-y-10">
                  {logs.filter(l => l.patientId === selectedPatient.id).sort((a,b) => b.date.localeCompare(a.date)).map(log => (
                    <div key={log.id} className="bg-white rounded-[4rem] shadow-xl p-12 space-y-10 border-l-[16px] border-l-emerald-500 animate-in fade-in slide-in-from-left-8 duration-500 hover:shadow-2xl transition-all relative">
                      <div className="flex justify-between items-start">
                        <div className="space-y-2">
                          <span className="text-[12px] font-black text-emerald-500 uppercase tracking-[0.3em]">{log.date}</span>
                          <h4 className="text-4xl font-black text-slate-800 tracking-tight">{log.activityName}</h4>
                        </div>
                        <div className="flex gap-4">
                           <button onClick={() => handleDeleteLog(log.id)} title="기록 삭제" className="p-5 rounded-[1.5rem] bg-slate-50 text-slate-300 hover:text-red-500 hover:bg-red-50 transition-all shadow-inner border border-slate-100">
                              <AlertCircle className="w-8 h-8" />
                           </button>
                        </div>
                      </div>
                      {/* whitespace-pre-wrap 적용: AI가 넣은 줄바꿈이 그대로 표시됨 */}
                      <div className="p-12 bg-slate-50 rounded-[3rem] text-slate-700 font-bold leading-[2.2] text-xl whitespace-pre-wrap shadow-inner border border-slate-100/50">
                        {log.generatedLog}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {view === 'generate_log' && selectedPatient && (
          <div className="max-w-4xl mx-auto animate-in slide-in-from-bottom-12 duration-700">
            <button onClick={() => setView('patient_detail')} className="mb-10 flex items-center gap-3 text-slate-400 hover:text-emerald-600 font-black text-xs uppercase tracking-widest transition-colors"><ArrowLeft className="w-6 h-6"/> 뒤로가기</button>
            <div className="bg-white p-12 md:p-24 rounded-[5rem] shadow-2xl relative overflow-hidden border border-slate-100">
              <div className="absolute top-0 left-0 w-4 h-full bg-emerald-500"></div>
              <h2 className="text-5xl font-black text-slate-800 tracking-tighter mb-6">AI 일지 일괄 생성</h2>
              <p className="text-slate-400 font-bold text-xl leading-relaxed">하이픈(-) 기호와 자동 상담 문구가 적용됩니다.<br/>생성된 기록은 시스템에 영구 보관됩니다.</p>
              
              <form onSubmit={handleGenerateBatchLogs} className="mt-20 space-y-16">
                <div className="space-y-6">
                  <label className="text-[12px] font-black text-slate-400 uppercase tracking-[0.4em] ml-4">치료 시작일 선택</label>
                  <input name="date" type="date" required defaultValue={new Date().toISOString().split('T')[0]} className="w-full p-8 bg-slate-50 border-none rounded-[2.5rem] font-black text-2xl shadow-inner outline-none focus:ring-4 focus:ring-emerald-500/10 transition-all" />
                </div>
                <div className="space-y-6">
                  <label className="text-[12px] font-black text-slate-400 uppercase tracking-[0.4em] ml-4">핵심 치료 활동 (키워드)</label>
                  <textarea name="activity" rows={6} className="w-full p-10 bg-slate-50 border-none rounded-[3rem] outline-none font-bold text-2xl text-slate-700 shadow-inner focus:ring-4 focus:ring-emerald-500/10 transition-all" placeholder="예: 시지각 변별력, 소근육 협응, 균형 감각 훈련 등"></textarea>
                </div>
                
                <button type="submit" disabled={isGenerating} className={`w-full py-10 rounded-[3rem] font-black text-3xl shadow-2xl flex items-center justify-center gap-8 transition-all ${isGenerating ? 'bg-slate-100 text-slate-300 cursor-not-allowed' : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-200 active:scale-[0.98]'}`}>
                  {isGenerating ? <><Loader2 className="w-12 h-12 animate-spin" /> 임상 데이터 분석 중...</> : <><Sparkles className="w-12 h-12"/> 5일치 일지 자동 생성</>}
                </button>
              </form>
            </div>
          </div>
        )}

        {view === 'add_patient' && (
          <div className="max-w-6xl mx-auto bg-white p-12 md:p-24 rounded-[5rem] shadow-2xl border border-slate-100 animate-in fade-in duration-700">
            <h2 className="text-5xl font-black text-slate-800 tracking-tighter mb-16 flex items-center gap-6">
              <UserPlus className="text-emerald-600 w-12 h-12" /> 신규 이용자 등록
            </h2>
            <form onSubmit={handleAddPatient} className="space-y-16">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
                <FormGroup label="이름" value={newPatientForm.name} onChange={(v:any) => setNewPatientForm({...newPatientForm, name: v})} required />
                <FormGroup label="생년월일" type="date" value={newPatientForm.birthDate} onChange={(v:any) => setNewPatientForm({...newPatientForm, birthDate: v})} required />
                <FormGroup label="치료 시작일" type="date" value={newPatientForm.therapyStartDate} onChange={(v:any) => setNewPatientForm({...newPatientForm, therapyStartDate: v})} required />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <FormGroup label="주 진단명" value={newPatientForm.diagnosis} onChange={(v:any) => setNewPatientForm({...newPatientForm, diagnosis: v as Diagnosis})} />
                <FormGroup label="장애정도" value={newPatientForm.disabilitySeverity} onChange={(v:any) => setNewPatientForm({...newPatientForm, disabilitySeverity: v as DisabilitySeverity})} />
              </div>
              <FormGroup label="주요 치료 목표 (쉼표 구분)" value={newPatientForm.goals} onChange={(v:any) => setNewPatientForm({...newPatientForm, goals: v})} placeholder="예: 시지각 변별력 향상, 눈-손 협응력 증진" required />
              <div className="space-y-6">
                 <label className="text-[12px] font-black text-slate-400 uppercase tracking-[0.4em] ml-4">초기 평가 및 관찰 소견</label>
                 <textarea value={newPatientForm.initialAssessment} onChange={(e) => setNewPatientForm({...newPatientForm, initialAssessment: e.target.value})} rows={10} className="w-full p-10 bg-slate-50 border-none rounded-[3rem] outline-none font-bold text-2xl text-slate-700 shadow-inner focus:ring-4 focus:ring-emerald-500/10 transition-all" placeholder="여기에 입력된 초기 평가 결과를 바탕으로 AI가 일지를 구성합니다."></textarea>
              </div>
              <div className="flex flex-col sm:flex-row gap-8 pt-12 border-t border-slate-50">
                <button type="button" onClick={() => setView('patients')} className="flex-1 py-8 border-2 border-slate-100 rounded-[2rem] font-black text-slate-400 hover:bg-slate-50 transition-all text-2xl uppercase tracking-widest">CANCEL</button>
                <button type="submit" className="flex-1 py-8 bg-emerald-600 text-white rounded-[2rem] font-black shadow-2xl hover:bg-emerald-700 transition-all text-2xl uppercase tracking-widest">REGISTER</button>
              </div>
            </form>
          </div>
        )}
      </main>
    </div>
  );
}

// --- Components ---
function NavItem({ active, onClick, icon, label }: any) {
  return (
    <button onClick={onClick} className={`w-full flex items-center gap-5 px-8 py-6 rounded-[2rem] transition-all group ${active ? 'bg-emerald-600 text-white shadow-2xl translate-x-2' : 'text-slate-500 hover:bg-slate-800/50 hover:text-white'}`}>
      {React.cloneElement(icon as React.ReactElement, { className: "w-6 h-6" })}
      <span className="font-black text-[12px] uppercase tracking-[0.2em]">{label}</span>
    </button>
  );
}

function StatCard({ icon, label, value }: any) {
  return (
    <div className="bg-white p-10 rounded-[3.5rem] shadow-xl border border-slate-50 flex items-center gap-10 group hover:scale-[1.03] transition-all">
      <div className="bg-slate-50 p-6 rounded-3xl group-hover:bg-white group-hover:shadow-md transition-all">
        {React.cloneElement(icon as React.ReactElement, { className: "w-10 h-10" })}
      </div>
      <div>
        <p className="text-[12px] font-black text-slate-400 uppercase tracking-widest mb-1">{label}</p>
        <p className="text-4xl font-black text-slate-800 tracking-tighter">{value}</p>
      </div>
    </div>
  );
}

function AssessmentBox({ title, date, content, theme, isExpanded, onToggle }: any) {
  const bg = { emerald: 'bg-emerald-50/50 border-emerald-100', blue: 'bg-blue-50/50 border-blue-100', purple: 'bg-purple-50/50 border-purple-100' }[theme as 'emerald' | 'blue' | 'purple'];
  const text = { emerald: 'text-emerald-600', blue: 'text-blue-600', purple: 'text-purple-600' }[theme as 'emerald' | 'blue' | 'purple'];

  return (
    <div className={`${bg} p-10 rounded-[3rem] border relative flex flex-col min-h-[220px] shadow-sm hover:shadow-md transition-all`}>
      <div className="flex justify-between items-start mb-8">
        <div>
          <p className={`text-[12px] font-black ${text} uppercase tracking-[0.3em] mb-1`}>{title}</p>
          <p className="text-[11px] font-black text-slate-400 uppercase">{date || 'TBD'}</p>
        </div>
        <button onClick={onToggle} className="text-[10px] bg-white border border-slate-100 px-5 py-3 rounded-2xl font-black text-slate-500 hover:bg-slate-50 transition-all shadow-sm">
          {isExpanded ? <><ChevronUp className="w-4 h-4 inline mr-1"/> 접기</> : <><ChevronDown className="w-4 h-4 inline mr-1"/> 보기</>}
        </button>
      </div>
      <div className={`text-lg text-slate-600 leading-relaxed font-bold whitespace-pre-wrap transition-all duration-500 overflow-hidden ${isExpanded ? 'max-h-[1500px]' : 'max-h-[120px] line-clamp-3'}`}>
        {content || "소견이 작성되지 않았습니다."}
      </div>
    </div>
  );
}

function FormGroup({ label, type = "text", value, onChange, required = false, placeholder }: any) {
  if (label === "주 진단명" || label === "장애정도") {
    const options = label === "주 진단명" ? Object.values(Diagnosis) : Object.values(DisabilitySeverity);
    return (
      <div className="space-y-4">
        <label className="text-[12px] font-black text-slate-400 uppercase tracking-[0.3em] ml-4">{label}</label>
        <select value={value} onChange={e => onChange(e.target.value)} className="w-full p-6 bg-slate-50 border-none rounded-2xl font-black text-xl shadow-inner outline-none focus:ring-4 focus:ring-emerald-500/10 transition-all">
          {options.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      </div>
    );
  }
  return (
    <div className="space-y-4">
      <label className="text-[12px] font-black text-slate-400 uppercase tracking-[0.3em] ml-4">{label}</label>
      <input type={type} value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)} required={required} className="w-full p-6 bg-slate-50 border-none rounded-2xl font-black text-xl shadow-inner outline-none focus:ring-4 focus:ring-emerald-500/10 transition-all" />
    </div>
  );
}
